from . import string_similarity
__name__ = 'mp_str_sim'