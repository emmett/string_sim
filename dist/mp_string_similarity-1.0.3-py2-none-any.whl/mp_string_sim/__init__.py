from .string_similarity import String_Sim
__name__ = 'mp_str_sim'